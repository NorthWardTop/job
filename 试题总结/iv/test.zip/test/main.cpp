#include <iostream>
#include <memory.h>

using namespace std;

int main()
{
    int num = 76421;
    int swp = 3;
    int decbit[10];
    memset(decbit, -1, sizeof(decbit));

    //获取每一位
    for (int i=0; num; ++i) {
        decbit[i] = num%10;
        num/=10;
    }

    //将数组逆序
    int pos=0;
    for (;decbit[pos] != -1; ++pos);
    pos--;
    for (int i = 0, j = pos; i < j; i++, j--)
    {
        int tmp = decbit[i];
        decbit[i] = decbit[j];
        decbit[j] = tmp;
    }

    //交换
    //外循环交换次数
    for (int i = 0; i < swp; ++i) {
        int min_index = i;
        //内循环找到最小值下标
        for (int j = i+1; decbit[j] != -1; ++j) {
            if (decbit[j] < decbit[min_index])
                min_index = j;
        }
        int tmp = decbit[i];
        decbit[i] = decbit[min_index];
        decbit[min_index] = tmp;
    }

    for (size_t i = 0; decbit[i] != -1; i++)
        cout << decbit[i];
    

}